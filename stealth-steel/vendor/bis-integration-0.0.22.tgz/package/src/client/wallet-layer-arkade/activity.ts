import { ReadonlyWallet, MnemonicIdentity, RestArkProvider, RestIndexerProvider, EsploraProvider, InMemoryWalletRepository, InMemoryContractRepository, assetMintResolver, type ArkTransaction } from '@arkade-os/sdk';
import { requireNetwork, operatorFor, type AccountSecret } from './account.ts';
import { testNetwork } from '../state-layer-core/test-network.ts';
import { validRecovery } from '../state-layer-core/recovery-validation.ts';
import { shareIndexerReads } from './indexer-reads.ts';
import type { BisTransaction } from '../state-layer-core/activity.ts';

type Coin = { txid: string; vout: number; value: number; status: { confirmed: boolean; block_height?: number } };
export function normalizeHistory(history: readonly ArkTransaction[], coins: readonly Coin[], tipHeight?: number, spendable: readonly {txid:string;vout:number;value:number}[] = []): readonly BisTransaction[] {
  // Preserve SDK records (including same-transaction outputs); reconcile snapshots, never append notifications.
  const occurrences = new Map<string, number>();
  const rows = history.map((tx): BisTransaction => {
    if (!Number.isSafeInteger(tx.amount) || tx.amount < 0 || !['RECEIVED', 'SENT'].includes(tx.type)) throw Error('Activity unavailable.');
    const { boardingTxid, commitmentTxid, arkTxid } = tx.key;
    const assets=tx.assets?.map(asset=>{
      // History uses signed deltas (change minus spent), unlike unsigned holdings.
      // Preserve the SDK sign and exact integer for outgoing assets and burns.
      if(typeof asset.assetId!=='string'||!asset.assetId||typeof asset.amount!=='bigint')throw Error('Asset history unavailable.');
      return Object.freeze({assetId:asset.assetId,quantity:asset.amount.toString()});
    });
    const kind=assets?.length ? assetMintResolver().resolve(tx)?.[0]?.label ?? 'Asset transfer' : undefined;
    const key = JSON.stringify([tx.type, boardingTxid, commitmentTxid, arkTxid, tx.amount]);
    const occurrence = occurrences.get(key) ?? 0;
    occurrences.set(key, occurrence + 1);
    const matches = coins.filter(c => c.txid === boardingTxid && c.value === tx.amount);
    // A unique match proves an outpoint. Ambiguous/spent history keeps only known IDs.
    const coin = matches.length === 1 ? matches[0] : undefined;
    const blockHeight = coin?.status.confirmed && Number.isSafeInteger(coin.status.block_height) && coin.status.block_height! > 0 ? coin.status.block_height : undefined;
    const confirmations = coin?.status.confirmed === false ? 0 : blockHeight !== undefined && Number.isSafeInteger(tipHeight) && tipHeight! >= blockHeight ? tipHeight! - blockHeight + 1 : undefined;
    const bitcoin = boardingTxid ? Object.freeze({txid:boardingTxid, confirmations, blockHeight}) : undefined;
    const createdAt = Number.isFinite(tx.createdAt) && tx.createdAt > 0 ? tx.createdAt : undefined;
    const offchain = !!arkTxid && !boardingTxid;
    const owned = spendable.filter(c => c.txid === arkTxid);
    const receiptVerified = offchain && tx.type === 'RECEIVED' && tx.amount > 0 && owned.length > 0
      && new Set(owned.map(c => c.vout)).size === owned.length
      && owned.every(c => Number.isSafeInteger(c.vout) && c.vout >= 0 && Number.isSafeInteger(c.value) && c.value > 0)
      && owned.reduce((sum,c) => sum + c.value, 0) === tx.amount;
    const status: BisTransaction['status'] = boardingTxid
      ? coin ? (coin.status.confirmed ? 'Confirmed' : 'Pending') : createdAt ? 'Confirmed' : 'Pending'
      : offchain ? (tx.settled ? 'Settled offchain' : 'Pending offchain') : 'Status unavailable';
    const refs = [boardingTxid && (coin ? `${boardingTxid}:${coin.vout}` : boardingTxid),
      commitmentTxid && `commitment:${commitmentTxid}`, arkTxid && `ark:${arkTxid}`].filter(Boolean);
    return Object.freeze({ id: `${key}:${occurrence}`, amountSats: tx.amount, direction: tx.type === 'SENT' ? 'Outgoing' : 'Incoming', status, identifier: refs.join(' ') || 'Identifier unavailable', ...(receiptVerified ? {receiptVerified:true} : {}), ...(bitcoin ? {bitcoin} : {}), ...(createdAt ? { createdAt } : {}),...(assets?.length?{assets:Object.freeze(assets),kind}:{}) });
  });
  const group = (t: BisTransaction) => t.createdAt ? 1 : t.status.startsWith('Pending') ? 0 : 2;
  rows.sort((a, b) => group(a) - group(b) || (b.createdAt ?? 0) - (a.createdAt ?? 0));
  return Object.freeze(rows);
}

export type ActivityWallet = Pick<ReadonlyWallet, 'getTransactionHistory' | 'getBoardingUtxos' | 'getProviderConnectionState' | 'notifyIncomingFunds' | 'dispose'> & Partial<Pick<ReadonlyWallet, 'onchainProvider' | 'getSpendableVtxos'>>;
// History fans out across boarding addresses and sequential historical outspend
// lookups. Give the complete SDK read a bounded minute, not one HTTP timeout.
export async function observeActivityWallet(pending: Promise<ActivityWallet>, signal: AbortSignal, publish: (rows: readonly BisTransaction[]) => void, healthy = () => true, intervalMs = 15000, requestTimeoutMs = 60000): Promise<void> {
  let wallet: ActivityWallet | undefined, stop: (() => void) | undefined;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let ended = false, reading = false, dirty = false;
  let finish!: () => void, fail!: (error: Error) => void;
  const finished = new Promise<void>((resolve, reject) => { finish = resolve; fail = reject; });
  const abort = () => { ended = true; finish(); };
  const failure = () => { ended = true; fail(Error('Activity unavailable.')); };
  const bounded = async <T,>(work: Promise<T>, timeoutMs = requestTimeoutMs): Promise<T> => {
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try { return await Promise.race([work, finished.then(() => { throw Error('Activity stopped.'); }), new Promise<never>((_, reject) => { timeout = setTimeout(() => reject(Error('Activity timed out.')), timeoutMs); })]); }
    finally { clearTimeout(timeout); }
  };
  signal.addEventListener('abort', abort, { once: true });
  if (signal.aborted) abort();
  const dispose=(w:ActivityWallet)=>{void Promise.resolve().then(()=>w.dispose()).catch(()=>{});};
  const acquired = pending.then(w => { if (ended) { dispose(w); throw Error('Activity stopped.'); } wallet = w; return w; });
  const read = async () => {
    if (ended) return;
    if (reading) { dirty = true; return; }
    reading = true;
    clearTimeout(timer);
    try {
      do {
        dirty = false;
        // A failed tip lookup must not hide otherwise valid transaction history.
        const tipRead = wallet!.onchainProvider ? bounded(Promise.resolve().then(() => wallet!.onchainProvider!.getChainTip()), Math.min(5000, requestTimeoutMs / 2)).catch(() => undefined) : Promise.resolve(undefined);
        const [history, coins, tip, spendable] = await bounded(Promise.all([wallet!.getTransactionHistory(), wallet!.getBoardingUtxos(), tipRead, wallet!.getSpendableVtxos?.({withRecoverable:false,withUnrolled:false}) ?? Promise.resolve([])]));
        const connection = wallet!.getProviderConnectionState();
        if (!healthy() || connection.mode !== 'online' || connection.source !== 'live') throw Error('Activity unavailable.');
        if (!ended) publish(normalizeHistory(history, coins, tip?.height, spendable));
      } while (dirty && !ended);
    } catch { if (!ended) failure(); }
    finally { reading = false; if (!ended) timer = setTimeout(() => void read(), intervalMs); }
  };
  try {
    await bounded(acquired);
    // Notifications accelerate updates; bounded polling remains sufficient when
    // subscription establishment stalls or fails. Never gate the initial read.
    const subscription = Promise.resolve().then(()=>wallet!.notifyIncomingFunds(() => void read())).then(unsubscribe => { if (ended) unsubscribe(); else stop = unsubscribe; });
    void bounded(subscription).catch(()=>{});
    await read();
    await finished;
  } finally {
    ended = true; finish(); clearTimeout(timer); signal.removeEventListener('abort', abort);
    try {stop?.();}catch {/* Cleanup must not hide the read outcome. */}
    if(wallet)dispose(wallet);
  }
}

export async function watchActivity(account: AccountSecret, signal: AbortSignal, publish: (rows: readonly BisTransaction[]) => void,session?:import('./adapter-session.ts').RoleWalletAccess): Promise<void> {
  if (!validRecovery(account.phrase)) throw Error('Invalid account.');
  signal.throwIfAborted();
  if(session)return session.read(account,signal,async wallet=>{
    // The observer owns callbacks/timers, never the retained SDK wallet.
    const borrowed:ActivityWallet={
      getTransactionHistory:()=>session.history(account,signal),getBoardingUtxos:()=>wallet.getBoardingUtxos(),
      getProviderConnectionState:()=>({mode:'online',source:'live',lastOnlineAt:Date.now()}),getSpendableVtxos:options=>session.read(account,signal,current=>current.getSpendableVtxos(options)),
      onchainProvider:wallet.onchainProvider,dispose:async()=>{},
      notifyIncomingFunds:async callback=>{
        const stop=new AbortController();
        void session.observe(account,AbortSignal.any([signal,stop.signal]),()=>callback({} as never)).catch(()=>{});
        return ()=>stop.abort();
      },
    };
    return observeActivityWallet(Promise.resolve(borrowed),signal,publish);
  },false);
  const network=account.network ?? 'signet',operator=operatorFor(network);
  const arkProvider = new RestArkProvider(operator);
  const getInfo = arkProvider.getInfo.bind(arkProvider);
  arkProvider.getInfo = async () => { const info = await getInfo(); requireNetwork(info.network,network); return info; };
  const indexerProvider = shareIndexerReads(new RestIndexerProvider(operator),operator);
  const onchainProvider = new EsploraProvider(testNetwork(network).explorerApiUrl, { forcePolling: true, pollingInterval: 15000 });
  let failed = false;
  const getVtxos = indexerProvider.getVtxos.bind(indexerProvider);
  indexerProvider.getVtxos = async (...args) => { try { signal.throwIfAborted(); return await getVtxos(...args); } catch (error) { failed = true; throw error; } };
  const getTransactions = onchainProvider.getTransactions.bind(onchainProvider);
  onchainProvider.getTransactions = async (...args) => { try { signal.throwIfAborted(); return await getTransactions(...args); } catch (error) { failed = true; throw error; } };
  await observeActivityWallet(ReadonlyWallet.create({
    identity: await MnemonicIdentity.fromMnemonic(account.phrase, { isMainnet: false }).toReadonly(), arkProvider, indexerProvider, onchainProvider,
    storage: { walletRepository: new InMemoryWalletRepository(), contractRepository: new InMemoryContractRepository() },
  }), signal, publish, () => !failed);
}
