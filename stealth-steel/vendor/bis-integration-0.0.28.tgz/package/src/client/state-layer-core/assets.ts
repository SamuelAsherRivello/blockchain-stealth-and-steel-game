export type BisAttributeDelta = Readonly<{bisAttribute: string; bisAttributeDelta: number}>;
export type BisAssetMetadataValue = string | number | boolean | null | readonly BisAttributeDelta[];
export type BisAssetMetadata = Readonly<Record<string, BisAssetMetadataValue>>;
import type { TestNetwork } from './test-network.ts';
import type { BisAssetDiagnostic } from './asset-operation-diagnostics.ts';
import type { BisAssetFormatResolution } from './asset-format.ts';
export type BisAsset = Readonly<{ assetId: string; name?: string; ticker?: string; quantity: string; decimals?: number; iconUrl?: string; metadata?: BisAssetMetadata; format?: BisAssetFormatResolution; sourceOperationId?: string; sourceTransactionId?: string }>;
export type BisMintAssetRequest = Readonly<{ operationId: string; name: string; ticker: string; amount: string; decimals: number; iconUrl?: string; metadata?: BisAssetMetadata }>;
export type BisAssetErrorCode = 'account-required' | 'invalid-input' | 'insufficient-funds' | 'unavailable' | 'outcome-unknown' | 'account-changed' | 'disposed' | 'unsupported-environment' | 'busy';
export type BisAssetError = Readonly<{ status: 'error'; code: BisAssetErrorCode; message: string; profileId?: string; operationId?: string; diagnostic?: BisAssetDiagnostic }>;
export type BisMintAssetResult = Readonly<{ status: 'minted' | 'already-minted'; profileId: string; operationId: string; asset: BisAsset; transactionId?: string }> | BisAssetError;
export type BisListAssetsResult = Readonly<{ status: 'success'; profileId: string; assets: readonly BisAsset[] }> | BisAssetError;
export type BisPendingMintResult = Readonly<{ status: 'success'; profileId: string; request: BisMintAssetRequest | null }> | BisAssetError;
const messages: Record<BisAssetErrorCode, string> = {
  'account-required': 'An active account is required.', 'invalid-input': 'Check the asset fields and operation ID. Amount must be positive and exactly representable.',
  'insufficient-funds': 'Insufficient spendable Arkade balance to mint an asset.', unavailable: 'Assets are unavailable. Try again.',
  'outcome-unknown': 'The mint is unresolved. Retry the same request to reconcile it; no new mint will be submitted.',
  'account-changed': 'The account changed during the request.', disposed: 'This client has been disposed.',
  'unsupported-environment': 'This browser cannot safely coordinate asset operations.', busy: 'Another wallet operation is in progress.',
};
export class AssetError extends Error {
  code: BisAssetErrorCode;
  constructor(code: BisAssetErrorCode) { super(messages[code]); this.code = code; }
}
export function assetError(code: BisAssetErrorCode, profileId?: string, operationId?: string, diagnostic?: BisAssetDiagnostic): BisAssetError {
  return { status: 'error', code, message: messages[code], ...(profileId ? { profileId } : {}), ...(operationId ? { operationId } : {}), ...(diagnostic ? { diagnostic } : {}) };
}
export function assetBaseUnits(amount: string, decimals: number): bigint {
  if (typeof amount !== 'string' || amount.length > 100 || !/^\d+(\.\d+)?$/.test(amount) || !Number.isInteger(decimals) || decimals < 0 || decimals > 18) throw new AssetError('invalid-input');
  const [whole, fraction = ''] = amount.split('.');
  if (fraction.length > decimals) throw new AssetError('invalid-input');
  const value = BigInt(whole + fraction.padEnd(decimals, '0'));
  if (value <= 0n || value > 18446744073709551615n) throw new AssetError('invalid-input');
  return value;
}
const reservedMetadata = new Set(['name','ticker','decimals','icon','bisKind','bisOperationId']);
export function decodeListedMetadataValue(value: unknown): unknown {
  if (typeof value !== 'string' || value.length === 0 || value.length % 2 !== 0 || !/^[0-9a-f]+$/i.test(value)) return value;
  try {
    const bytes = Uint8Array.from(value.match(/../g)!, pair => Number.parseInt(pair, 16));
    return new TextDecoder('utf-8', {fatal:true}).decode(bytes);
  } catch {
    return value;
  }
}
function metadataValue(value: unknown, key?: string): value is BisAssetMetadataValue {
  if (value === null || typeof value === 'string' || typeof value === 'boolean'
    || (typeof value === 'number' && Number.isFinite(value) && Number.isSafeInteger(value))) return true;
  if (key !== 'bisAttributeDeltas' || !Array.isArray(value) || value.length > 16) return false;
  const attributes = new Set<string>();
  for (const entry of value) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return false;
    const keys = Object.keys(entry);
    if (keys.some(entryKey => !['bisAttribute', 'bisAttributeDelta'].includes(entryKey))) return false;
    if (typeof entry.bisAttribute !== 'string' || !/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(entry.bisAttribute)
      || attributes.has(entry.bisAttribute)) return false;
    if (entry.bisAttributeDelta !== undefined
      && (typeof entry.bisAttributeDelta !== 'number' || !Number.isFinite(entry.bisAttributeDelta) || !Number.isSafeInteger(entry.bisAttributeDelta) || entry.bisAttributeDelta < -100 || entry.bisAttributeDelta > 100)) return false;
    attributes.add(entry.bisAttribute);
  }
  return true;
}
export function normalizeAssetMetadata(input: unknown, mode: 'mint' | 'list' = 'mint'): BisAssetMetadata | undefined {
  if (input === undefined) return;
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    if (mode === 'mint') throw new AssetError('invalid-input');
    return;
  }
  const entries: [string, BisAssetMetadataValue][] = [];
  for (const [key,rawValue] of Object.entries(input)) {
    let value = mode === 'list' ? decodeListedMetadataValue(rawValue) : rawValue;
    if (mode === 'list' && key === 'bisAttributeDeltas' && typeof value === 'string') {
      try { value = JSON.parse(value); } catch { continue; }
    }
    if (reservedMetadata.has(key)) {
      if (mode === 'mint') throw new AssetError('invalid-input');
      continue;
    }
    if (!/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(key) || ['__proto__','prototype','constructor'].includes(key) || !metadataValue(value, key) || (typeof value === 'string' && value.length > 2048)) {
      if (mode === 'mint') throw new AssetError('invalid-input');
      continue;
    }
    if (key === 'bisAttributeDeltas') {
      if (!Array.isArray(value)) {
        if (mode === 'mint') throw new AssetError('invalid-input');
        continue;
      }
      const deltas = (value as readonly BisAttributeDelta[]).map(delta => Object.freeze({
        bisAttribute: delta.bisAttribute,
        bisAttributeDelta: delta.bisAttributeDelta ?? 0,
      }));
      entries.push([key, Object.freeze(deltas)]);
    } else entries.push([key,value]);
  }
  entries.sort(([a],[b])=>a.localeCompare(b));
  if (!entries.length) return;
  const normalized = Object.freeze(Object.fromEntries(entries)) as BisAssetMetadata;
  if (JSON.stringify(normalized).length > 4096) {
    if (mode === 'mint') throw new AssetError('invalid-input');
    return;
  }
  return normalized;
}
export function validateMint(input: BisMintAssetRequest): BisMintAssetRequest {
  const text = (v: unknown, max: number): v is string => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
  if (!input || !text(input.operationId, 128) || !/^[\w-]+$/.test(input.operationId) || !text(input.name, 128) || !text(input.ticker, 16) || 'controlAssetId' in input) throw new AssetError('invalid-input');
  assetBaseUnits(input.amount, input.decimals);
  if (input.iconUrl !== undefined && input.iconUrl !== '') {
    try { const url = new URL(input.iconUrl); if (url.protocol !== 'https:' || url.username || url.password || input.iconUrl.length > 2048) throw Error(); }
    catch { throw new AssetError('invalid-input'); }
  }
  const metadata = normalizeAssetMetadata(input.metadata);
  return Object.freeze({operationId: input.operationId, name: input.name, ticker: input.ticker, amount: input.amount, decimals: input.decimals, ...(input.iconUrl ? {iconUrl: input.iconUrl} : {}), ...(metadata ? {metadata} : {})});
}
export type AssetRecord = { request: BisMintAssetRequest; status: 'pending' | 'succeeded'; asset?: BisAsset; transactionId?: string; network?: TestNetwork };
const recordKey = (profileId: string,network:TestNetwork='signet') => `bis-${network}-mints-v1:${encodeURIComponent(profileId)}`;
export function readAssetRecords(profileId: string,network:TestNetwork='signet'): AssetRecord[] {
  try {
    const raw = localStorage.getItem(recordKey(profileId,network));
    if (raw === null) return [];
    const r = JSON.parse(raw);
    if (r.version !== 1 || !Array.isArray(r.operations)) throw Error();
    const ids = new Set();
    for (const op of r.operations) {
      validateMint(op.request);
      if (ids.has(op.request.operationId) || (op.network??'signet')!==network || !['pending', 'succeeded'].includes(op.status) || (op.status === 'succeeded' && (!op.asset || typeof op.asset.assetId !== 'string' || typeof op.asset.quantity !== 'string'))) throw Error();
      ids.add(op.request.operationId);
    }
    return r.operations;
  } catch { throw new AssetError('outcome-unknown'); }
}
export function checkMintRecord(profileId: string, request: BisMintAssetRequest,network:TestNetwork='signet'): AssetRecord | undefined {
  const records = readAssetRecords(profileId,network);
  const existing = records.find(r => r.request.operationId === request.operationId);
  if (existing && JSON.stringify(validateMint(existing.request)) !== JSON.stringify(validateMint(request))) throw new AssetError('invalid-input');
  if (records.some(r => r.status === 'pending' && r.request.operationId !== request.operationId)) throw new AssetError('outcome-unknown');
  return existing;
}
export function writeAssetRecord(profileId: string, record: AssetRecord) {
  const network=record.network ?? 'signet',records = readAssetRecords(profileId,network);
  const i = records.findIndex(r => r.request.operationId === record.request.operationId);
  if (i >= 0) records[i] = record; else records.push(record);
  try {
    const key = recordKey(profileId,network), value = JSON.stringify({version: 1, operations: records.map(item=>({...item,network}))});
    localStorage.setItem(key, value);
    if (localStorage.getItem(key) !== value) throw Error();
  } catch { throw new AssetError('unavailable'); }
}
